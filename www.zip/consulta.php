<?php

require('config/routeros_api.class.php');

$ip = $_POST['ip'];
$usuario = $_POST['usuario'];
$senha = $_POST['senha'];

$API = new routeros_api();


if ($API->connect($ip, $usuario, $senha)) {

   $ARRAY = $API->comm("/system/resource/print");
   $ram =  $ARRAY['0']['free-memory']/1048576;
   $hdd =  $ARRAY['0']['free-hdd-space']/1048576;
}

?>