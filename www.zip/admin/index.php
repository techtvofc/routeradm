<?php
    session_start();
     if ( !isset( $_SESSION['usuarioNome'] ) ) 
{ 
    header("Location: ../index.php");
 }  

require_once('../config/routeros_api.class.php');
require_once('../conexao.php');

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>GERENCIAMENTO - SISTEMA DE GERENCIAMENTO DE RB</title>

    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="../assets/css/main.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js"></script>
</head>

<body>
    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3>GERENCIA</h3>
            </div>

            <ul class="list-unstyled components">
                <p><? echo $_SESSION['usuarioNome']; ?></p>
                <li class="active">
                    <a href="#">Página Inicial</a>
                </li>
                <li>
                    <a href="#servidores" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Servidores</a>
                    <ul class="collapse list-unstyled" id="servidores">
                        <li>
                            <a href="pages/adicionar_servidor.php">Adicionar Servidores</a>
                        </li>
                        <li>
                            <a href="pages/listar_servidores.php">Listar Servidores</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#usuarios" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Usuários</a>
                    <ul class="collapse list-unstyled" id="usuarios">
                        <li>
                            <a href="#">Adicionar admin</a>
                        </li>
                        <li>
                            <a href="#">Lista de admin</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#">Alterar Senha</a>
                </li>
                <li>
                    <a href="sair.php">Sair</a>
                </li>
            </ul>
        </nav>

        <!-- Page Content  -->
        <div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-orange">
                        <i class="fas fa-align-left"></i>
                    </button>

                </div>
            </nav>

            <div class="container-fluid">


                <h2>Lista de servidores</h2>
                <p class="lead">
                    Informações do servidor principal
                </p>

                <div class="row">

                    <? 
                        $result_usuarios = "SELECT * FROM ros_admin";
                        $resultado_usuarios = mysqli_query($conn, $result_usuarios);
                        $row_usuario = mysqli_fetch_assoc($resultado_usuarios);

                        $API = new routeros_api();


                        if ($API->connect($row_usuario['ip'], $row_usuario['usuario'], $row_usuario['senha'])) {

                           $ARRAY = $API->comm("/system/resource/print");
                           $ram =  $ARRAY['0']['free-memory']/1048576;
                           $hdd =  $ARRAY['0']['free-hdd-space']/1048576;
                        }
                     ?>

                <div class="col-md">
                    <div class="card btn-orange mb-3" style="max-width: 18rem;">
                      <div class="card-header">IP</div>
                      <div class="card-body">
                        <h5 class="card-title"><? echo $row_usuario['ip'] ?></h5>
                      </div>
                    </div>
                </div>
                <div class="col-md">
                    <div class="card btn-orange mb-3" style="max-width: 18rem;">
                      <div class="card-header">RAM</div>
                      <div class="card-body">
                        <h5 class="card-title"><? echo "".round($ram,1)." MB" ?></h5>
                      </div>
                    </div>
                </div>
                <div class="col-md">
                    <div class="card btn-orange mb-3" style="max-width: 18rem;">
                      <div class="card-header">MEMÓRIA</div>
                      <div class="card-body">
                        <h5 class="card-title"><? echo "".round($hdd,1)." MB"; ?></h5>
                      </div>
                    </div>
                </div>
                <div class="col-md">
                    <div class="card btn-orange mb-3" style="max-width: 18rem;">
                      <div class="card-header">CPU</div>
                      <div class="card-body">
                        <h5 class="card-title"><? echo "".$ARRAY['0']['cpu-load']." %"; ?></h5>
                      </div>
                    </div>
                </div>
            </div>

                <p class="lead">Servidores adicionados recentemente</p>

                <table class="table table-dark">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">NOME</th>
                      <th scope="col">IP</th>
                      <th scope="col">RAM</th>
                      <th scope="col">MEMÓRIA</th>
                      <th scope="col">GERIR</th>
                    </tr>
                  </thead>

                  <?

                    $result_usuarios = "SELECT * FROM ros_servers";
                    $resultado_usuarios = mysqli_query($conn, $result_usuarios);
                    while ($row_usuario = mysqli_fetch_assoc($resultado_usuarios)) {

                        $API = new routeros_api();


                        if ($API->connect($row_usuario['ip'], $row_usuario['usuario'], $row_usuario['senha'])) {

                           $ARRAY = $API->comm("/system/resource/print");
                           $ram =  $ARRAY['0']['free-memory']/1048576;
                           $hdd =  $ARRAY['0']['free-hdd-space']/1048576;
                        }
                        
                        echo "<tr>";
                            echo "<td>".$row_usuario['id']."</td>";
                            echo "<td>".$row_usuario['nome']."</td>";
                            echo "<td>".$row_usuario['ip']."</td>";
                            echo "<td>".round($ram,1)." MB</td>";
                            echo "<td>".round($hdd,1)." MB</td>";
                            echo "<td><center>";
                                            if($API->connect($row_usuario['ip'], $row_usuario['usuario'], $row_usuario['senha'])){
                                              echo "<center><button type=\"button\" class=\"btn btn-success\"><i class=\"fa fa-check\"></i> CONECTADO&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button></center>";
                                              $conn="connect";  
                                            }else{
                                              echo "<center><button type=\"button\" class=\"btn btn-danger\"><i class=\"fa fa-times\"></i> DESCONECTADO</button></center>";
                                              $conn="disconnect";
                                            }                                 
                                          echo "</td>";
                            echo "<td><a href='server/conn_server.php?id=".$row_usuario['id']."&conn=".$conn."'><center><button type=\"button\" class=\"btn btn-success\" title=\"Acessar Servidor\"><i class=\"fa fa-arrow-right\"></i></button></center></a>";                        
                                        echo "</td>";
                        echo "</tr>";

                    }

                  ?>
                  <tbody>
                  </tbody>
                </table>
            </div>


            

        </div>
    </div>

    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
    </script>
</body>

</html>